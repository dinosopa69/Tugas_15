<?php 
header("Location:daftar.php");
 ?>